﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Stibo.Timesheet.Data;

namespace Stibo.Timesheet.Business
{
    /// <summary>
    /// Summary description for UserModule
    /// </summary>
    public class UserModule
    {
        public UserModule()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}